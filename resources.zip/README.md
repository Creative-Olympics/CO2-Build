# CO2-Ressource-Pack
 
Documentation:


### Diamond hoe (Organizers logos)
| CustomModelData | Texture |
| --- | --- |
| 1 | Gunivers |
| 2 | Altearn |
| 3 | CO2023 |
| 4 | CO |

### Golden hoe (Partners logos)
| CustomModelData | Texture |
| --- | --- |

### Iron hoe (Banners)
| CustomModelData | Texture |
| --- | --- |